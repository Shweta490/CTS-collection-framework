public interface TuitionFee {
    int calculateTuitionFees(String courseType, int basicFee, int noOfSemesters);
}